import java.net.*;
import java.io.*;

//TODO:
//remove unnecessary comments, do light commenting to explain methods

public class JavaServer_FINAL extends Thread {

	 private ServerSocket serverSocket;										// Declaration of the socket that the server will run on
	 private String userMessage = "";
	 
	 private String userMark = "";
	 private String userOneMark = "";
	 private char charOneMark = ' ';
	 private String userTwoMark = "";
	 private char charTwoMark = ' ';
	 private String recentMark = " ";
	 private String winnerMark = "";
	 
	 private boolean userOneMarkSet = false;
	 private boolean userTwoMarkSet = false;
	 
	 private boolean movePlayed = false;
	 private boolean winnerFound = false;
	 
	 private String strPlayList = "                ";
	 private char[][] playList = new char[4][4];
	 private byte letterIteration = 0;
	 
	  public JavaServer_FINAL(int port) throws IOException
	   {
	      serverSocket = new ServerSocket(port);								// Instantiates the server socket
	      serverSocket.setSoTimeout(0);										// Sets the timeout for the socket. A timeout of 0 establishes
	   }																		// an infinite timeout
	
	  
	  public void run()
	   {
	      while(true)
	      {
	         try
	         {
	            System.out.println("Waiting for client on port " +				// Output informational message that the server is waiting
	            serverSocket.getLocalPort() + "...");							// for a client on the specified port
	            
	            Socket server = serverSocket.accept();							// Wait for a connection from the client
	            
	            System.out.println("Just connected to "							// Output informational message that the server is connected
	                  + server.getRemoteSocketAddress());						// to the client at the specified IP address
	            
	            DataOutputStream out =											// Prepare the object for returning data to the client
		                 new DataOutputStream(server.getOutputStream());
	            
	            DataInputStream in =											// Get the data from the client (new message)
	                  new DataInputStream(server.getInputStream());
	            
	            movePlayed = in.readBoolean();
	            
	            
	            //PRESS BUTTON METHOD  ----------------------------------------------------------------------
	            if (movePlayed == true)
	            {
	            	System.out.println("Button Pressed");
	            	
	            	userMark = in.readUTF();
	            	
	            	//if at least one mark is not set
	            	if (userOneMarkSet == true && userTwoMarkSet == false)
	            	{
	            		userTwoMark = userMark;
	            		recentMark = userTwoMark;
	            		userTwoMarkSet = true;
	            	}
	            	if (userOneMarkSet == false && userTwoMarkSet == false)
	            	{
	            		userOneMark = userMark;
	            		recentMark = userOneMark;
	            		userOneMarkSet = true;
	            	}
	            	
	            	//if both marks are set
	            	if (userOneMarkSet == true && userTwoMarkSet == true)
	            	{
	            		//if a player is recent mark, it is not their turn to play
	            		if (recentMark == userOneMark)
	            		{
	            			recentMark = userTwoMark;
	            		}
	            		else 
	            		{
	            			recentMark = userOneMark;
	            		}
	            	}
	            	
	            	strPlayList = in.readUTF();
	            	
	            	updateArray();
	            	
	            	checkForFour();
	            	
	            }
	            
	            //UPDATE METHOD -----------------------------------------------------------------------------
	            if (movePlayed == false)
	            {
	            	System.out.println("Update Called");
	            	
	            	//return playList
	            	out.writeUTF(strPlayList);
	            	
	            	//return if winner is found
	            	out.writeBoolean(winnerFound);
	            	
	            	
	            }
	            

	            server.close();													// Shut down the server
	         }catch(SocketTimeoutException s)
	         {
	            System.out.println("Socket timed out!");
	            break;
	         }catch(IOException e)
	         {
	            e.printStackTrace();
	            break;
	         }
	      }
	   }
	   public static void main(String [] args)
	   {
	      //int port = Integer.parseInt(args[0]);          						// Used to permit command prompt invocation
		   
	      int port = 6066;														// Establish port 6066 as a hard-coded port override
		   
	      try
	      {
	         Thread t = new JavaServer_FINAL(port);								// Instantiates a server on a separate thread
	         t.start();															// Executes the server
	      }catch(IOException e)
	      {
	         e.printStackTrace();
	      }
	   }
	   
	   private void checkForFour()
	   {
		   
		   //horizontal row 0
		   if (playList[0][0] == playList[0][1] && playList[0][0] == playList[0][2]
				   && playList[0][0] == playList[0][3] && playList[0][0] != ' ')
		   {
			   winnerFound = true;
			   if (recentMark == userOneMark)
			   {
				   winnerMark = Character.toString(charOneMark);
			   }
			   else
			   {
				   winnerMark = Character.toString(charTwoMark);
			   }
		   }
		   
		   //horizontal row 1
		   if (playList[1][0] == playList[1][1] && playList[1][0] == playList[1][2]
				   && playList[1][0] == playList[1][3] && playList[1][0] != ' ')
		   {
			   winnerFound = true;
			   if (recentMark == userOneMark)
			   {
				   winnerMark = Character.toString(charOneMark);
			   }
			   else
			   {
				   winnerMark = Character.toString(charTwoMark);
			   }
		   }
		   
		   //horizontal row 2
		   if (playList[2][0] == playList[2][1] && playList[2][0] == playList[2][2]
				   && playList[2][0] == playList[2][3] && playList[2][0] != ' ')
		   {
			   winnerFound = true;
			   if (recentMark == userOneMark)
			   {
				   winnerMark = Character.toString(charOneMark);
			   }
			   else
			   {
				   winnerMark = Character.toString(charTwoMark);
			   }
		   }
		   
		   //horizontal row 3
		   if (playList[3][0] == playList[3][1] && playList[3][0] == playList[3][2]
				   && playList[3][0] == playList[3][3] && playList[3][0] != ' ')
		   {
			   winnerFound = true;
			   if (recentMark == userOneMark)
			   {
				   winnerMark = Character.toString(charOneMark);
			   }
			   else
			   {
				   winnerMark = Character.toString(charTwoMark);
			   }
		   }
		   
		   //vertical column 0
		   if (playList[0][0] == playList[1][0] && playList[0][0] == playList[2][0]
				   && playList[0][0] == playList[3][0] && playList[0][0] != ' ')
		   {
			   winnerFound = true;
			   if (recentMark == userOneMark)
			   {
				   winnerMark = Character.toString(charOneMark);
			   }
			   else
			   {
				   winnerMark = Character.toString(charTwoMark);
			   }
		   }
		   
		 //vertical column 1
		   if (playList[0][1] == playList[1][1] && playList[0][1] == playList[2][1]
				   && playList[0][1] == playList[3][1] && playList[0][1] != ' ')
		   {
			   winnerFound = true;
			   if (recentMark == userOneMark)
			   {
				   winnerMark = Character.toString(charOneMark);
			   }
			   else
			   {
				   winnerMark = Character.toString(charTwoMark);
			   }
		   }
		   
		 //vertical column 2
		   if (playList[0][2] == playList[1][2] && playList[0][2] == playList[2][2]
				   && playList[0][2] == playList[3][2] && playList[0][2] != ' ')
		   {
			   winnerFound = true;
			   if (recentMark == userOneMark)
			   {
				   winnerMark = Character.toString(charOneMark);
			   }
			   else
			   {
				   winnerMark = Character.toString(charTwoMark);
			   }
		   }
		   
		 //vertical column 3
		   if (playList[0][3] == playList[1][3] && playList[0][3] == playList[2][3]
				   && playList[0][3] == playList[3][3] && playList[0][3] != ' ')
		   {
			   winnerFound = true;
			   if (recentMark == userOneMark)
			   {
				   winnerMark = Character.toString(charOneMark);
			   }
			   else
			   {
				   winnerMark = Character.toString(charTwoMark);
			   }
		   }
		   
		   //diagonal from top left
		   if (playList[0][0] == playList[1][1] && playList[0][0] == playList[2][2]
				   && playList[0][0] == playList[3][3] && playList[0][0] != ' ')
		   {
			   winnerFound = true;
			   if (recentMark == userOneMark)
			   {
				   winnerMark = Character.toString(charOneMark);
			   }
			   else
			   {
				   winnerMark = Character.toString(charTwoMark);
			   }
		   }
		   
		   //diagonal from top right
		   if (playList[0][3] == playList[1][2] && playList[0][3] == playList[2][1]
				   && playList[0][3] == playList[3][0] && playList[0][3] != ' ')
		   {
			   winnerFound = true;
			   if (recentMark == userOneMark)
			   {
				   winnerMark = Character.toString(charOneMark);
			   }
			   else
			   {
				   winnerMark = Character.toString(charTwoMark);
			   }
		   }
		   
		   if (winnerFound == true)
		   {
			   System.out.println("Winner found " + winnerMark);
		   }
		   
	   }

	   
	   private void updateArray()
	   {
		   for (int row = 0; row < 4; row++) {
       		for (int col = 0; col < 4; col++)
       		{
       			playList[row][col] = strPlayList.charAt(letterIteration);
       			
       			letterIteration++;
       			System.out.print(playList[row][col]);
       			
       		}
       		System.out.println();
       	}
		   letterIteration = 0;
	   }
	
}
