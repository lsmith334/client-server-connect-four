import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.net.*;
import java.io.*;

import javax.swing.Timer;

public class JavaClient_FINAL extends JFrame implements ActionListener {

	private JPanel contentPane;
	private static JLabel lblWinner;
	private static JButton btnR0C0;
	private static char charR0C0 = ' ';
	private static JButton btnR0C1;
	private static char charR0C1 = ' ';
	private static JButton btnR0C2;
	private static char charR0C2 = ' ';
	private static JButton btnR0C3;
	private static char charR0C3 = ' ';
	private static JButton btnR1C0;
	private static char charR1C0 = ' ';
	private static JButton btnR1C1;
	private static char charR1C1 = ' ';
	private static JButton btnR1C2;
	private static char charR1C2 = ' ';
	private static JButton btnR1C3;
	private static char charR1C3 = ' ';
	private static JButton btnR2C0;
	private static char charR2C0 = ' ';
	private static JButton btnR2C1;
	private static char charR2C1 = ' ';
	private static JButton btnR2C2;
	private static char charR2C2 = ' ';
	private static JButton btnR2C3;
	private static char charR2C3 = ' ';
	private static JButton btnR3C0;
	private static char charR3C0 = ' ';
	private static JButton btnR3C1;
	private static char charR3C1 = ' ';
	private static JButton btnR3C2;
	private static char charR3C2 = ' ';
	private static JButton btnR3C3;
	private static char charR3C3 = ' ';
	
	private static char[] playList = new char[16];
	private static String strPlayList = "";
	
	private static String strPlayerMark = "";
	private static char playerMark = 'a';
	private static boolean turnPlayed = false;
	private static boolean winnerFound = false;
	
	
	static String serverName  = "localhost";								// Establish the local machine as the server
	static int port = 6066;													// Hard-code port for connection
	
    static Socket client;
    static OutputStream outToServer;
    static DataOutputStream out;
    static InputStream inFromServer;
    static DataInputStream in;
    
    private static final Integer FRAMETIME = 500;
	
	private Timer tickTock = new Timer(FRAMETIME,this);									// instantiate a timer object
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				
				for (int iterate = 0; iterate < 16; iterate++)
				{
					playList[iterate] = ' ';
					strPlayList += playList[iterate];
				}
				System.out.println("strPlayList: " + strPlayList + ";");
				
				strPlayerMark = JOptionPane.showInputDialog("Please input your mark value:");
				playerMark = strPlayerMark.charAt(0);
				strPlayerMark = Character.toString(playerMark);
				
				try {
					JavaClient_FINAL frame = new JavaClient_FINAL();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JavaClient_FINAL() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 465, 590);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTitle = new JLabel("Connect Four");
		lblTitle.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitle.setBounds(10, 11, 420, 74);
		contentPane.add(lblTitle);
		
		lblWinner = new JLabel("Game in progress...");
		lblWinner.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblWinner.setHorizontalAlignment(SwingConstants.CENTER);
		lblWinner.setBounds(10, 75, 420, 43);
		contentPane.add(lblWinner);
		
		btnR0C0 = new JButton(" ");
		btnR0C0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonPressed(0);
				updateButtons();
			}
		});
		btnR0C0.setBounds(20, 130, 95, 95);
		contentPane.add(btnR0C0);
		
		btnR0C1 = new JButton(" ");
		btnR0C1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonPressed(1);
				updateButtons();
			}
		});
		btnR0C1.setBounds(125, 129, 95, 95);
		contentPane.add(btnR0C1);
		
		btnR0C2 = new JButton(" ");
		btnR0C2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonPressed(2);
				updateButtons();
			}
		});
		btnR0C2.setBounds(230, 129, 95, 95);
		contentPane.add(btnR0C2);
		
		btnR0C3 = new JButton(" ");
		btnR0C3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonPressed(3);
				updateButtons();
			}
		});
		btnR0C3.setBounds(335, 129, 95, 95);
		contentPane.add(btnR0C3);
		
		btnR1C0 = new JButton(" ");
		btnR1C0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonPressed(4);
				updateButtons();
			}
		});
		btnR1C0.setBounds(20, 235, 95, 95);
		contentPane.add(btnR1C0);
		
		btnR1C1 = new JButton(" ");
		btnR1C1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonPressed(5);
				updateButtons();
			}
		});
		btnR1C1.setBounds(125, 235, 95, 95);
		contentPane.add(btnR1C1);
		
		btnR1C2 = new JButton(" ");
		btnR1C2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonPressed(6);
				updateButtons();
			}
		});
		btnR1C2.setBounds(230, 235, 95, 95);
		contentPane.add(btnR1C2);
		
		btnR1C3 = new JButton(" ");
		btnR1C3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonPressed(7);
				updateButtons();
			}
		});
		btnR1C3.setBounds(335, 235, 95, 95);
		contentPane.add(btnR1C3);
		
		btnR2C0 = new JButton(" ");
		btnR2C0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonPressed(8);
				updateButtons();
			}
		});
		btnR2C0.setBounds(20, 340, 95, 95);
		contentPane.add(btnR2C0);
		
		btnR2C1 = new JButton(" ");
		btnR2C1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonPressed(9);
				updateButtons();
			}
		});
		btnR2C1.setBounds(125, 340, 95, 95);
		contentPane.add(btnR2C1);
		
		btnR2C2 = new JButton(" ");
		btnR2C2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonPressed(10);
				updateButtons();
			}
		});
		btnR2C2.setBounds(230, 340, 95, 95);
		contentPane.add(btnR2C2);
		
		btnR2C3 = new JButton(" ");
		btnR2C3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonPressed(11);
				updateButtons();
			}
		});
		btnR2C3.setBounds(335, 340, 95, 95);
		contentPane.add(btnR2C3);
		
		btnR3C0 = new JButton(" ");
		btnR3C0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonPressed(12);
				updateButtons();
			}
		});
		btnR3C0.setBounds(20, 445, 95, 95);
		contentPane.add(btnR3C0);
		
		btnR3C1 = new JButton(" ");
		btnR3C1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonPressed(13);
				updateButtons();
			}
		});
		btnR3C1.setBounds(125, 445, 95, 95);
		contentPane.add(btnR3C1);
		
		btnR3C2 = new JButton(" ");
		btnR3C2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonPressed(14);
				updateButtons();
			}
		});
		btnR3C2.setBounds(230, 445, 95, 95);
		contentPane.add(btnR3C2);
		
		btnR3C3 = new JButton(" ");
		btnR3C3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				buttonPressed(15);
				updateButtons();
			}
		});
		btnR3C3.setBounds(335, 445, 95, 95);
		contentPane.add(btnR3C3);
		
		tickTock.start();																	// start the timer
	}
	
	static void updateGame()
	{
		
		try {
			
			client = new Socket(serverName, port);							//establish a connection
			
			outToServer = client.getOutputStream();
			out = new DataOutputStream(outToServer);
			
			inFromServer = client.getInputStream();
			in = new DataInputStream(inFromServer);
			
			turnPlayed = false;
			out.writeBoolean(turnPlayed);
			
			strPlayList = in.readUTF();
			System.out.println(strPlayList);
			updateArray();
			
			updateButtons();
			
			winnerFound = in.readBoolean();
			if (winnerFound == false)
			System.out.println("false");
			else
			{
				lblWinner.setText("Winner Found...");
				buttonLock(false);
			}
				
			
			
			client.close();	
			
			} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	static void buttonPressed(int index)
	{
		
		try {
			
			client = new Socket(serverName, port);							//establish a connection
			
			outToServer = client.getOutputStream();
			out = new DataOutputStream(outToServer);
			
			inFromServer = client.getInputStream();
			in = new DataInputStream(inFromServer);
			
			turnPlayed = true;
			out.writeBoolean(turnPlayed);
			
			out.writeUTF(strPlayerMark);
			
			playList[index] = playerMark;
			
			updateArray();
			
			System.out.println(strPlayList);
			
			out.writeUTF(strPlayList);
			
			updateButtons();
			
			//buttonLock(false);
			
			client.close();	
			
			} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	static void updateButtons()
	{
		//TODO:
		//update every button text
		//disable buttons after being pressed
		
		
		btnR0C0.setText(Character.toString(playList[0]));
		charR0C0 = btnR0C0.getText().charAt(0);
		if (charR0C0 != ' ')
		{
			btnR0C0.setEnabled(false);
		}
		btnR0C1.setText(Character.toString(playList[1]));
		charR0C1 = btnR0C1.getText().charAt(0);
		if (charR0C1 != ' ')		
		{
			btnR0C1.setEnabled(false);
		}
		btnR0C2.setText(Character.toString(playList[2]));
		charR0C2 = btnR0C2.getText().charAt(0);
		if (charR0C2 != ' ')		
		{
			btnR0C2.setEnabled(false);
		}
		btnR0C3.setText(Character.toString(playList[3]));
		charR0C3 = btnR0C3.getText().charAt(0);
		if (charR0C3 != ' ')		
		{
			btnR0C3.setEnabled(false);
		}
		btnR1C0.setText(Character.toString(playList[4]));
		charR1C0 = btnR1C0.getText().charAt(0);
		if (charR1C0 != ' ')		
		{
			btnR1C0.setEnabled(false);
		}
		btnR1C1.setText(Character.toString(playList[5]));
		charR1C1 = btnR1C1.getText().charAt(0);
		if (charR1C1 != ' ')		
		{
			btnR1C1.setEnabled(false);
		}
		btnR1C2.setText(Character.toString(playList[6]));
		charR1C2 = btnR1C2.getText().charAt(0);
		if (charR1C2 != ' ')		
		{
			btnR1C2.setEnabled(false);
		}
		btnR1C3.setText(Character.toString(playList[7]));
		charR1C3 = btnR1C3.getText().charAt(0);
		if (charR1C3 != ' ')		
		{
			btnR1C3.setEnabled(false);
		}
		btnR2C0.setText(Character.toString(playList[8]));
		charR2C0 = btnR2C0.getText().charAt(0);
		if (charR2C0 != ' ')		
		{
			btnR2C0.setEnabled(false);
		}
		btnR2C1.setText(Character.toString(playList[9]));
		charR2C1 = btnR2C1.getText().charAt(0);
		if (charR2C1 != ' ')		
		{
			btnR2C1.setEnabled(false);
		}
		btnR2C2.setText(Character.toString(playList[10]));
		charR2C2 = btnR2C2.getText().charAt(0);
		if (charR2C2 != ' ')		
		{
			btnR2C2.setEnabled(false);
		}
		btnR2C3.setText(Character.toString(playList[11]));
		charR2C3 = btnR2C3.getText().charAt(0);
		if (charR2C3 != ' ')		
		{
			btnR2C3.setEnabled(false);
		}
		btnR3C0.setText(Character.toString(playList[12]));
		charR3C0 = btnR3C0.getText().charAt(0);
		if (charR3C0 != ' ')		
		{
			btnR3C0.setEnabled(false);
		}
		btnR3C1.setText(Character.toString(playList[13]));
		charR3C1 = btnR3C1.getText().charAt(0);
		if (charR3C1 != ' ')		
		{
			btnR3C1.setEnabled(false);
		}
		btnR3C2.setText(Character.toString(playList[14]));
		charR3C2 = btnR3C2.getText().charAt(0);
		if (charR3C2 != ' ')		
		{
			btnR3C2.setEnabled(false);
		}
		btnR3C3.setText(Character.toString(playList[15]));
		charR3C3 = btnR3C3.getText().charAt(0);
		if (charR3C3 != ' ')		
		{
			btnR3C3.setEnabled(false);
		}
		
		
	}
	
	static void buttonLock(boolean mode)
	{
		//false = locked, true = unlocked
		
		btnR0C0.setEnabled(mode);
		btnR0C1.setEnabled(mode);
		btnR0C2.setEnabled(mode);
		btnR0C3.setEnabled(mode);
		btnR1C0.setEnabled(mode);
		btnR1C1.setEnabled(mode);
		btnR1C2.setEnabled(mode);
		btnR1C3.setEnabled(mode);
		btnR2C0.setEnabled(mode);
		btnR2C1.setEnabled(mode);
		btnR2C2.setEnabled(mode);
		btnR2C3.setEnabled(mode);
		btnR3C0.setEnabled(mode);
		btnR3C1.setEnabled(mode);
		btnR3C2.setEnabled(mode);
		btnR3C3.setEnabled(mode);
		
	}
	
	static void updateArray()
	{
		
		if (turnPlayed == true)
		{
			//convert array to string
			strPlayList = "";
		
			for (int iterate = 0; iterate < 16; iterate++)
			{
				strPlayList += playList[iterate];
			}
		
		}
		else
		{
			//convert string to array
			playList = strPlayList.toCharArray();
		}
		
		turnPlayed = false;
		
	}


@Override
public void actionPerformed(ActionEvent e) {
	// TODO Auto-generated method stub
	
	updateGame();
	
}

}
